---
name: answer
description: How Claude answers a question from the wiki. Read the trusted shelf first, then drafts, then raw only if asked, and always say which shelf the answer came from.
---

# answer (callable entry point)

The full answer workflow lives in `skills/answer.md` at the wiki project root. That file is the
single source of truth — this skill just makes it callable as `/answer`.

Do this now:

1. Read `CLAUDE.md` at the project root if you have not this session. Its three layers are the
   whole idea.
2. Open `skills/answer.md` (project root, not this file) and follow it step by step, exactly as
   written. Do not summarise it from memory — read the current version.
