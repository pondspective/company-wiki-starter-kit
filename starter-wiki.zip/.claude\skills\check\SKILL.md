---
name: check
description: Check a draft from the knowledge layer with a second person, then move it onto the trusted wiki shelf. This is the only way a note gets to be trusted.
---

# check (callable entry point)

The full check-and-publish workflow lives in `skills/check.md` at the wiki project root. That
file is the single source of truth — this skill just makes it callable as `/check`.

Do this now:

1. Read `CLAUDE.md` at the project root if you have not this session. Its three rules and three
   layers always win.
2. Open `skills/check.md` (project root, not this file) and follow it step by step, exactly as
   written. Do not summarise it from memory — read the current version.
