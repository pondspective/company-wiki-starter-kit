---
name: grill
description: The interview Claude follows when someone wants to write something down, or when a raw dump needs turning into a real note. Ask one question at a time, in plain language, pin down the fuzzy parts, then save a clean draft into the knowledge layer.
---

# grill (callable entry point)

The full interview workflow lives in `skills/grill.md` at the wiki project root. That file is
the single source of truth — this skill just makes it callable as `/grill`.

Do this now:

1. Read `CLAUDE.md` at the project root if you have not this session. Its three rules and three
   layers always win.
2. Open `skills/grill.md` (project root, not this file) and follow it step by step, exactly as
   written. Do not summarise it from memory — read the current version.
